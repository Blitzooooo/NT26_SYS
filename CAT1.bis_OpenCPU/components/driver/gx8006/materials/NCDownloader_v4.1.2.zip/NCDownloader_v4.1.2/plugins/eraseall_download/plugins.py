from ..gxpluginsbase import GxWidgetType
from ..gxpluginsbase import GxPluginsBase

class GxPlugins(GxPluginsBase):
    def __init__(self, mainwindow):
        super().__init__(mainwindow)

    def on_init(self):
        self.widget = [
                {"name":"start_addr", "text": "Start Addr:", "type": GxWidgetType.EDIT,     "init_value": "0"},
                {"name":"bin_file",   "text": "Bin File:",   "type": GxWidgetType.OPENFILE, "init_value": ""},
                {"name":"reboot",     "text": "Completed:",  "type": GxWidgetType.CHECKBOX, "title": "Reboot", "init_value": True},
                ]
        return True

    def on_create_commond(self, param):
        if param["bin_file"] == "":
            self.show_error_message("Error", "Please choose to download file!")
            return False,None
        if self.check_num(param["start_addr"]) == False:
            self.show_error_message("Error", "Please set download address!")
            return False,None

        cmd_str = ""
        cmd_str += "flash eraseall;download "+ param["start_addr"] + " " + '"' + param["bin_file"] + '"';
        if param["reboot"]:
            cmd_str += ';reboot'

        cmd = [ cmd_str ]
        return True, cmd

