from enum import Enum

class GxWidgetType(Enum):
    '''自定义控件类型
        - COMBOBOX  : 下拉列表控件, 有 name、text、list、init_value 参数
        - EDIT      : 编辑控件,     有 name、text、init_value help(可选) 参数
        - SAVEFILE  : 保存文件控件, 有 name、text、init_value help(可选) 参数
        - OPENFILE  : 打开文件控件, 有 name、text、init_value help(可选) 参数
        - CHECKFILE : 单选框控件,   有 name、text、title、init_value 参数
    '''
    COMBOBOX = 'combobox'
    EDIT     = 'edit'
    SAVEFILE = 'savefile'
    OPENFILE = 'openfile'
    CHECKBOX = 'checkbox'

class GxPluginsBase():
    ''' 插件基类，所有的自定义命令插件都应该继承这个这个基类 '''

    def __init__(self, mainwindow):
        self.mainwindow = mainwindow

        ''' 配置界面上的自定义控件, 详细说明参考 GxWidgetType
            可以定义多个同一类型的控件，每种类型的控件数量有以下限制：
             - COMBOBOX 控件：最多可定义 3 个
             - EDIT 控件    ：最多可定义 3 个
             - SAVEFILE 控件：最多可定义 2 个
             - OPENFILE 控件：最多可定义 2 个
             - CHECKBOX 控件：最多可定义 2 个
        例如：
        self.widget = [
                {"name":"start_addr", "text": "Start Addr:", "type": GxWidgetType.EDIT,     "init_value": "0"},
                {"name":"mac_addr",   "text": "Mac Addr:",   "type": GxWidgetType.EDIT,     "init_value": "", "help": "xx:xx:xx:xx:xx:xx"},
                {"name":"bin_file",   "text": "Bin File:",   "type": GxWidgetType.OPENFILE, "init_value": ""},
                {"name":"dump_file",  "text": "Dump File:",  "type": GxWidgetType.SAVEFILE, "init_value": ""},
                {"name":"test",       "text": "test:",       "type": GxWidgetType.COMBOBOX, "list":["test1", "test2"], "init_value": "test2"},
                {"name":"reboot",     "text": "Completed:",  "type": GxWidgetType.CHECKBOX, "title": "Reboot", "init_value": True},
                ]
        '''
        self.widget = []

        '''支持的芯片，None 代表支持所有芯片， ['apus', 'grus'] 代表支持apus、grus
           可选值为 leo leo_mini grus aquila apus fornax
        例如：
        self.chip = ['apus']
        '''
        self.chip = None

    def on_init(self):
        '''初始化，主程序初始化时会主动调用此函数
           返回：返回 False 代表执行失败，不会添加此命令，返回 True 代表执行成功
        '''
        return True

    def show_error_message(self, title: str, message: str, detailed_msg: str=None):
        '''弹窗显示错误信息
            - title : 弹窗标题
            - message : 弹窗信息
            - detaile_msg : 弹窗详细内容
        '''
        self.mainwindow.show_error_message(title, message, detailed_msg)

    def write_log(self, msg: str):
        '''写日志信息，会同时写到界面日志窗口和日志文件
            - msg: 日志内容
        '''
        self.mainwindow.append_log(msg)

    def check_num(self, value: str):
        '''判断是否是数值
            - value: 字符串类型
           返回：是数值返回 True，否则返回 False
        '''
        return self.mainwindow.check_num(value)

    def on_runtime_log(self, cmd_index: int, msg: str):
        '''当收到命令执行的日志时会主动调用此函数，每收到一行日志调用一次
            - cmd_index : 命令列表的序号, 从0开始编号
            - msg : 一行日志内容
        '''
        pass

    def on_finish_log(self, cmd_index: int, result: bool, msg: str):
        '''当命令执行完成后会主动调用此函数
            - cmd_index : 命令列表的序号, 从0开始编号
            - result: 命令执行结果, True 代表命令正常执行完成，False 代表命令执行异常
            - msg: 命令执行完整日志
           返回：返回 False 代表执行失败，不再执行剩下的命令，返回 True 代表执行成功
        '''
        return True

    def on_create_commond(self, param: dict):
        '''当执行命令前会后主动调用此函数,获取需要执行的命令
            - param: 配置的控件值
           返回：返回两个值的元组
                 第一个参数返回 False 代表执行失败，不执行该命令命令，返回 True 代表执行成功
                 第二个参数是需要依此执行的命令列表,是bootx工具里的 -c 参数字段，只有第一个参数为 True 时，这个参数才有效

              例如：return True,["dump 0 0x1000 ./a.bin", "download 0 ./a.bin"]
                当 "dump 0 0x1000 ./a.bin" 执行完成以后，框架会调用 on_finish_log() 并且cmd_index为0，msg为执行的打印，这样就可以在下个命令执行前做一些处理
                当 "download 0 ./a.bin"  执行完成以后，框架会调用 on_finish_log() 并且cmd_index为1
                也可以在 on_finish_log() 修改未执行的命令列表或添加新的命令
        '''
        return False, None

