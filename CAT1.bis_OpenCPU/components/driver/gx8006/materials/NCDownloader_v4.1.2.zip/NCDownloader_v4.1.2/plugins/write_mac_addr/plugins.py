from ..gxpluginsbase import GxWidgetType
from ..gxpluginsbase import GxPluginsBase
import re
import os

def is_valid_mac_address(mac: str):
    mac_regex = re.compile(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$')
    if mac_regex.match(mac):
        return True
    else:
        return False

def align_address_to_4kb(addr_str: str):
    if addr_str.startswith('0x'):
        address = int(addr_str, 16)
    else:
        address = int(addr_str)

    aligned_address = (address // 4096) * 4096
    offset_addr = address % 4096

    # 将4KB对齐的地址转换回字符串格式（十六进制）
    aligned_address_str = '0x{:x}'.format(aligned_address)
    return aligned_address_str, offset_addr

def mac_str_to_bytes(mac_str: str):
    mac_str_no_sep = mac_str.replace(":", "").replace("-", "")
    # 将MAC地址转换为6个字节的数值
    mac_bytes = bytes.fromhex(mac_str_no_sep)
    return mac_bytes

def replace_mac_in_bin_file(file_path: str, offset_addr: int, mac_str: str):
    # 将MAC地址字符串转换为6个字节的数值
    mac_bytes = mac_str_to_bytes(mac_str)
    with open(file_path, 'rb') as file:
        file_content = bytearray(file.read())

    # 确保偏移地址合法
    if offset_addr + len(mac_bytes) > len(file_content):
        return False

    # 替换偏移地址处的6个字节
    file_content[offset_addr:offset_addr + len(mac_bytes)] = mac_bytes
    with open(file_path, 'wb') as file:
        file.write(file_content)
    return True

class GxPlugins(GxPluginsBase):

    def __init__(self, mainwindow):
        super().__init__(mainwindow)
        self.temp_file = "./temp_file_mac_1234.bin"
        self.offset_addr = 0
        self.mac_addr = 0

    def on_init(self):
        self.chip = ["apus"]
        self.widget = [
                {"name":"start_addr",  "text": "Start Addr:", "type": GxWidgetType.EDIT,     "init_value": "0"},
                {"name":"mac_addr",    "text": "Mac Addr:",   "type": GxWidgetType.EDIT,     "init_value": "", "help": "xx:xx:xx:xx:xx:xx"},
                ]
        return True

    def on_finish_log(self, cmd_index: int, result: bool, msg: str):
        if result == False:
            return False
        if cmd_index == 0:
            if "SUCCESS" not in msg:
                return False
            ret = replace_mac_in_bin_file(self.temp_file, self.offset_addr, self.mac_addr)
            if ret == False:
                self.show_error_message("Error", "The mac address spans two Flash blocks!")
                return False
        elif cmd_index == 1:
            try:
                os.remove(self.temp_file)
            except:
                pass

        return True

    def on_create_commond(self, param):
        if self.check_num(param["start_addr"]) == False:
            self.show_error_message("Error", "Please set start address!")
            return False,None
        if is_valid_mac_address(param["mac_addr"]) == False:
            self.show_error_message("Error", "Please set a valid mac address")
            return False,None
        self.mac_addr = param["mac_addr"]

        addr, self.offset_addr = align_address_to_4kb(param["start_addr"])

        cmd_str1 = "dump "+ addr + " 0x1000 " + '"' + self.temp_file + '"'
        cmd_str2 = "download "+ addr + " " + '"' + self.temp_file + '"'

        cmd = [ cmd_str1, cmd_str2 ]
        return True, cmd

