from ..gxpluginsbase import GxWidgetType
from ..gxpluginsbase import GxPluginsBase

class GxPlugins(GxPluginsBase):

    def __init__(self, mainwindow):
        super().__init__(mainwindow)

    def on_init(self):
        self.chip = ["apus"]
        self.widget = [
                {"name":"start_addr", "text": "Start Addr:", "type": GxWidgetType.EDIT,     "init_value": "0"},
                {"name":"length",     "text": "Length:",     "type": GxWidgetType.EDIT,     "init_value": ""},
                {"name":"sdpinmux",   "text": "sdpinmux:",   "type": GxWidgetType.EDIT,     "init_value": "", "help": "xx xx xx xx xx xx"},
                {"name":"save_file",  "text": "Save File:",  "type": GxWidgetType.SAVEFILE, "init_value": ""},
                {"name":"reboot",     "text": "Completed:",  "type": GxWidgetType.CHECKBOX, "title": "Reboot", "init_value": True},
                ]
        return True

    def on_create_commond(self, param):
        if self.check_num(param["start_addr"]) == False:
            self.show_error_message("Error", "Please set dump address!")
            return False,None
        if self.check_num(param["length"]) == False:
            self.show_error_message("Error", "Please set dump length!")
            return False,None
        if param["save_file"] == "":
            self.show_error_message("Error", "Please choose to save dump file!")
            return False,None

        cmd_str = ""
        if param["sdpinmux"] != "":
            cmd_str += "sdpinmux " + param["sdpinmux"] + ";"
        cmd_str += "sddump "+ param["start_addr"] + " " + param["length"] + " " + '"' + param["save_file"] + '"'
        if param["reboot"]:
            cmd_str += ';reboot'

        cmd = [ cmd_str ]
        return True, cmd

